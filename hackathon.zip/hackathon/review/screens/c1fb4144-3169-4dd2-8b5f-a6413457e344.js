var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1200" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1637170132791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1637170132791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1637170132791-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-c1fb4144-3169-4dd2-8b5f-a6413457e344" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Asignatura" width="1200" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/c1fb4144-3169-4dd2-8b5f-a6413457e344-1637170132791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/c1fb4144-3169-4dd2-8b5f-a6413457e344-1637170132791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/c1fb4144-3169-4dd2-8b5f-a6413457e344-1637170132791-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="552.5px" datasizeheight="207.2px" dataX="0.0" dataY="-0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9ea1eea8-10da-4439-be9d-8b51f3ee68b7.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer commentable non-processed" customid="Red de Colegios de Am&eacute;ric"   datasizewidth="647.5px" datasizeheight="207.6px" dataX="552.5" dataY="-0.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Red de Colegios de Am&eacute;rica Latina</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer commentable non-processed" customid="ASIGNATURA"   datasizewidth="1200.0px" datasizeheight="95.0px" dataX="-0.0" dataY="207.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">ASIGNATURA</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph" class="pie richtext autofit firer ie-background commentable non-processed" customid="Nombre"   datasizewidth="90.4px" datasizeheight="26.0px" dataX="82.0" dataY="364.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_0">Nombre</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="ID asignatura"   datasizewidth="143.9px" datasizeheight="26.0px" dataX="82.0" dataY="420.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">ID asignatura</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Descripci&oacute;n"   datasizewidth="128.5px" datasizeheight="26.0px" dataX="82.0" dataY="476.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Descripci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Grado o nivel"   datasizewidth="142.5px" datasizeheight="26.0px" dataX="82.0" dataY="533.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Grado o nivel</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="&Aacute;rea"   datasizewidth="50.1px" datasizeheight="26.0px" dataX="82.0" dataY="590.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">&Aacute;rea</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Metodolog&iacute;a"   datasizewidth="137.4px" datasizeheight="26.0px" dataX="82.0" dataY="645.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Metodolog&iacute;a</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="396.0px" datasizeheight="40.0px" dataX="276.2" dataY="362.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input" title="Asignado por el colegio" datasizewidth="396.0px" datasizeheight="40.0px" dataX="276.2" dataY="414.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="396.0px" datasizeheight="40.0px" dataX="276.2" dataY="470.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="396.0px" datasizeheight="40.0px" dataX="276.2" dataY="584.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Category_1" class="pie dropdown firer commentable non-processed" customid="Category"    datasizewidth="214.0px" datasizeheight="40.0px" dataX="276.2" dataY="638.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Magistral</div></div></div></div></div><select id="s-Category_1-options" class="s-c1fb4144-3169-4dd2-8b5f-a6413457e344 dropdown-options" ><option selected="selected" class="option">Magistral</option>\
      <option  class="option">Aprendizaje Inverso</option>\
      <option  class="option">Gamificaci&oacute;n</option>\
      <option  class="option">Design Thinking</option>\
      <option  class="option">Pensamiento Computacional</option>\
      <option  class="option">STEAM</option>\
      <option  class="option">Otro</option></select></div>\
      <div id="s-Category" class="pie dropdown firer commentable non-processed" customid="Category"    datasizewidth="90.0px" datasizeheight="40.0px" dataX="276.2" dataY="531.5"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">6&ordm;</div></div></div></div></div><select id="s-Category-options" class="s-c1fb4144-3169-4dd2-8b5f-a6413457e344 dropdown-options" ><option selected="selected" class="option">6&ordm;</option>\
      <option  class="option">7&ordm;</option>\
      <option  class="option">8&ordm;</option>\
      <option  class="option">9&ordm;</option>\
      <option  class="option">10&ordm;</option>\
      <option  class="option">11&ordm;</option></select></div>\
      <div id="s-Button" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Guardar"   datasizewidth="120.0px" datasizeheight="54.0px" dataX="552.2" dataY="705.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_0">Guardar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;