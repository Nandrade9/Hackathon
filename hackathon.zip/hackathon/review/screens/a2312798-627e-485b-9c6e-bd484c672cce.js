var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1637170132791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1637170132791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-a2312798-627e-485b-9c6e-bd484c672cce" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Docente" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/a2312798-627e-485b-9c6e-bd484c672cce-1637170132791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/a2312798-627e-485b-9c6e-bd484c672cce-1637170132791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/a2312798-627e-485b-9c6e-bd484c672cce-1637170132791-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer commentable non-processed" customid="Red de Colegios de Am&eacute;ric"   datasizewidth="727.5px" datasizeheight="207.6px" dataX="552.5" dataY="-0.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Red de Colegios de Am&eacute;rica Latina</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="552.5px" datasizeheight="207.2px" dataX="0.0" dataY="-0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9ea1eea8-10da-4439-be9d-8b51f3ee68b7.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="1280.0px" datasizeheight="92.5px" datasizewidthpx="1280.0" datasizeheightpx="92.52173913043484" dataX="-0.0" dataY="207.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="PROFESOR"   datasizewidth="1282.0px" datasizeheight="95.0px" dataX="-0.0" dataY="207.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">PROFESOR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_35" class="pie image firer ie-background commentable non-processed" customid="Image_35"   datasizewidth="50.0px" datasizeheight="55.0px" dataX="44.0" dataY="226.0"   alt="image" systemName="./images/53209487-bb42-4733-97bc-2eb098f007f6.svg" overlay="#1BDAF1">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
          	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
          	    <title>user</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#666666" id="s-Image_35-user">\
          	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#1BDAF1 !important;" />\
          	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#1BDAF1 !important;" />\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Content_1" class="group firer ie-background commentable non-processed" customid="Content_1" datasizewidth="1024.0px" datasizeheight="400.0px" >\
        <div id="s-Line_1" class="pie path firer ie-background commentable non-processed" customid="Line_1"   datasizewidth="3.0px" datasizeheight="242.0px" dataX="502.0" dataY="363.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="2.0" height="241.0" viewBox="502.0 363.5 2.0 241.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_1-a2312" d="M503.0 364.0 L503.0 604.0 "></path>\
            	    </defs>\
            	    <g>\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_1-a2312" fill="none" stroke-width="1.0" stroke="#F2F2F2" stroke-linecap="butt" filter="none"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_15" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Configuraci&oacute;n"   datasizewidth="187.9px" datasizeheight="50.0px" dataX="106.0" dataY="352.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_15_0">Configuraci&oacute;n</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_14" class="pie richtext manualfit firer ie-background commentable non-processed" customid="PersonalContrase&ntilde;a"   datasizewidth="145.8px" datasizeheight="96.0px" dataX="294.0" dataY="390.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_14_0">Personal<br />Contrase&ntilde;a</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_16" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="103.8px" datasizeheight="54.0px" dataX="242.0" dataY="550.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_16_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_18" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Mis asignaturas"   datasizewidth="209.6px" datasizeheight="64.0px" dataX="106.0" dataY="472.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_18_0">Mis asignaturas</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_13" class="pie image firer ie-background commentable non-processed" customid="Image_13"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="56.0" dataY="350.0"   alt="image" systemName="./images/98d59cbd-bcb3-426e-adee-93cf7f02a8ba.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 24 24" width="24px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Dribbble Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_13-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#DDDDDD" id="s-Image_13-Components" transform="translate(-683.000000, -934.000000)">\
          	            <g id="s-Image_13-Social" transform="translate(100.000000, 849.000000)">\
          	                <g id="s-Image_13-Rounded-Icons" transform="translate(515.000000, 85.000000)">\
          	                    <g id="s-Image_13-Dribbble-Icon" transform="translate(68.000000, 0.000000)">\
          	                        <path d="M12,24 C5.372583,24 0,18.627417 0,12 C0,5.372583 5.372583,0 12,0 C18.627417,0 24,5.372583 24,12 C24,18.627417 18.627417,24 12,24 Z M18,12 C18,8.688 15.312,6 12,6 C8.688,6 6,8.688 6,12 C6,15.312 8.688,18 12,18 C15.312,18 18,15.312 18,12 Z M8.856,16.044 L8.736,15.948 C8.772,15.984 8.808,16.008 8.856,16.032 L8.856,16.044 Z M12.552,11.976 C10.848,12.468 9.048,13.896 8.184,15.42 L8.196,15.432 C7.344,14.484 6.876,13.26 6.876,12 L6.876,11.832 C8.58,11.88 10.524,11.592 12.144,11.112 C12.288,11.4 12.432,11.688 12.552,11.976 Z M14.004,16.716 C13.368,16.992 12.684,17.124 12,17.124 C10.86,17.124 9.756,16.74 8.856,16.032 C8.988,15.744 9.192,15.468 9.384,15.228 C10.308,14.076 11.484,13.32 12.876,12.84 L12.9,12.828 C13.392,14.076 13.776,15.396 14.004,16.716 Z M11.712,10.32 C10.224,10.716 8.628,10.956 7.08,10.944 L6.984,10.944 C7.32,9.372 8.364,8.052 9.816,7.368 C10.512,8.304 11.148,9.3 11.712,10.32 Z M17.064,12.816 C16.836,14.208 16.032,15.456 14.868,16.248 C14.652,15.012 14.292,13.776 13.86,12.588 C14.22,12.528 14.58,12.504 14.928,12.504 C15.636,12.504 16.392,12.6 17.064,12.816 Z M15.384,8.16 C14.856,8.976 13.584,9.684 12.708,10.008 C12.144,8.976 11.508,7.956 10.788,7.02 C11.184,6.924 11.592,6.876 12,6.876 C13.248,6.876 14.448,7.332 15.384,8.16 Z M17.124,11.952 C16.344,11.784 15.528,11.712 14.736,11.712 C14.34,11.712 13.944,11.736 13.548,11.784 C13.416,11.436 13.26,11.1 13.104,10.776 C14.028,10.392 15.372,9.6 15.96,8.748 C16.704,9.648 17.112,10.776 17.124,11.952 Z" style="fill:#CBCBCB !important;" />\
          	                    </g>\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed" customid="Image_1"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="56.0" dataY="482.3"   alt="image" systemName="./images/148d7ce7-014e-466f-8d72-09fdbdddd16b.svg" overlay="#B2B2B2">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="21px" version="1.1" viewBox="0 0 21 21" width="21px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>True Stroked Copy 10</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_2-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#B2B2B2" id="Price-tables-#1" transform="translate(-136.000000, -213.000000)">\
          	            <g id="s-Image_2-True-Stroked-Copy-10" transform="translate(136.000000, 213.000000)">\
          	                <path d="M5.02923077,11.305 C4.94307692,11.214 4.9,11.0775 4.9,10.9865 C4.9,10.8955 4.94307692,10.759 5.02923077,10.668 L5.63230769,10.031 C5.80461538,9.849 6.06307692,9.849 6.23538462,10.031 L6.27846154,10.0765 L8.64769231,12.761 C8.73384615,12.852 8.86307692,12.852 8.94923077,12.761 L14.7215385,6.4365 L14.7650462,6.4365 C14.9369231,6.2545 15.1958154,6.2545 15.3676923,6.4365 L15.9707692,7.0735 C16.1430769,7.2555 16.1430769,7.5285 15.9707692,7.7105 L9.07846154,15.2635 C8.99230769,15.3545 8.90615385,15.4 8.77692308,15.4 C8.64769231,15.4 8.56153846,15.3545 8.47538462,15.2635 L5.11538462,11.4415 L5.02923077,11.305 Z M18.9,10.5 C18.9,15.12 15.12,18.9 10.5,18.9 C5.859,18.9 2.1,15.12 2.1,10.5 C2.1,5.88 5.88,2.1 10.5,2.1 C15.12,2.1 18.9,5.88 18.9,10.5 L18.9,10.5 Z M10.5,0 C4.704,0 0,4.704 0,10.5 C0,16.296 4.704,21 10.5,21 C16.296,21 21,16.296 21,10.5 C21,4.704 16.296,0 10.5,0 Z" id="s-Image_2-True-Stroked" style="fill:#B2B2B2 !important;" />\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Diamond" class="pie rectangle manualfit firer click commentable non-processed" customid="Diamond" rotationdeg="45.0"  datasizewidth="50.0px" datasizeheight="50.0px" datasizewidthpx="50.0" datasizeheightpx="50.0" dataX="56.0" dataY="591.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Diamond_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Circle" customid="Circle" class="shapewrapper shapewrapper-s-Circle non-processed"   datasizewidth="50.0px" datasizeheight="50.0px" datasizewidthpx="50.0" datasizeheightpx="50.0" dataX="56.0" dataY="696.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Circle" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Circle)">\
                          <ellipse id="s-Circle" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Circle" cx="25.0" cy="25.0" rx="25.0" ry="25.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Circle" class="clipPath">\
                          <ellipse cx="25.0" cy="25.0" rx="25.0" ry="25.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Circle" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Circle_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Paragraph_19" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Mis asignaturas"   datasizewidth="209.6px" datasizeheight="64.0px" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_19_0">Mis asignaturas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Cooperaciones"   datasizewidth="200.7px" datasizeheight="54.0px" dataX="129.0" dataY="597.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_0">Cooperaciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Control"   datasizewidth="200.7px" datasizeheight="54.0px" dataX="129.0" dataY="706.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Control</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_6"   datasizewidth="629.5px" datasizeheight="404.0px" datasizewidthpx="629.5000000000002" datasizeheightpx="403.9710144927536" dataX="585.0" dataY="356.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Inscribir asignatura"   datasizewidth="631.5px" datasizeheight="62.0px" dataX="584.0" dataY="356.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Inscribir asignatura</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="40.0px" dataX="756.0" dataY="450.7" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="A&ntilde;o"   datasizewidth="42.7px" datasizeheight="27.0px" dataX="618.6" dataY="457.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">A&ntilde;o</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Calendario"   datasizewidth="116.1px" datasizeheight="27.0px" dataX="618.6" dataY="518.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Calendario</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="40.0px" dataX="756.0" dataY="512.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Contenido"   datasizewidth="116.1px" datasizeheight="27.0px" dataX="618.6" dataY="584.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Contenido </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Adjuntar"   datasizewidth="106.0px" datasizeheight="40.0px" dataX="982.0" dataY="572.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_0">Adjuntar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="40.0px" dataX="756.0" dataY="572.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="Link"   datasizewidth="44.0px" datasizeheight="27.0px" dataX="618.0" dataY="649.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">Link</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Plataforma"   datasizewidth="116.1px" datasizeheight="27.0px" dataX="622.8" dataY="719.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">Plataforma</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="40.0px" dataX="756.0" dataY="642.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="40.0px" dataX="756.0" dataY="712.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;