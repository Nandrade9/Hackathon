	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Paragraph_2", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["h1", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Paragraph_1", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_4", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Input", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Input_1", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Input_3", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Category_1", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Category", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Category", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Custom Select List", "s-Category"]; 

	widgets.descriptionMap[["s-Button", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "c1fb4144-3169-4dd2-8b5f-a6413457e344"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_2", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["h1", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_10", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Cell", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_9", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Cell_2", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_14", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Text", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Cell_4", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_11", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Text", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Cell_6", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_12", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Text", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Cell_8", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_13", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Text", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Cell_10", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_10", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_15", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Text", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Cell_1", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_16", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Text", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Cell_3", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_5", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_5", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_7", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_9", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_9", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_11", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_11", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_12", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_12", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_13", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_13", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_14", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_14", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_15", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_15", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_16", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_16", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_17", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_17", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_18", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_18", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_19", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_19", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_20", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_20", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_21", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_21", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_22", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_22", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_23", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_23", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Image_30", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Image_30", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Three dots menu icon", "s-Image_30"]; 

	widgets.descriptionMap[["s-Image_31", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Image_31", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Three dots menu icon", "s-Image_31"]; 

	widgets.descriptionMap[["s-Image_9", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Right arrow in circle", "s-Image_9"]; 

	widgets.descriptionMap[["s-Image_19", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Check mark", "s-Image_19"]; 

	widgets.descriptionMap[["s-Ellipse_1", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Button", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "0c624dc8-70cc-459f-96a6-ee401dcd0b18"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_2", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["h1", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Rectangle", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Paragraph", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Category", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Category", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Custom Select List", "s-Category"]; 

	widgets.descriptionMap[["s-Paragraph_1", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Category_1", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Paragraph_4", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Category_2", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Custom Select List", "s-Category_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Category_3", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_3", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Custom Select List", "s-Category_3"]; 

	widgets.descriptionMap[["s-Paragraph_6", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Category_4", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_4", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Custom Select List", "s-Category_4"]; 

	widgets.descriptionMap[["s-Paragraph_7", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Category_5", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Category_5", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Custom Select List", "s-Category_5"]; 

	widgets.descriptionMap[["s-Cell", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_9", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Cell_2", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_4", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_11", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Cell_6", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_6", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_12", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Cell_8", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_8", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_13", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Cell_10", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_10", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_1", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_3", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_5", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_5", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_7", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_7", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_9", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_9", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Cell_11", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_11", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_8", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_10", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Image_9", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "bc778dde-907b-4bf8-8215-d2a82d89df7b"]] = ["Right arrow in circle", "s-Image_9"]; 

	widgets.descriptionMap[["s-Paragraph", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Rectangle", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h1", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h1", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h1", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Gray button", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Gray button", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Gray button", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Gray button", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Input", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Button", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_2", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Rectangle", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Paragraph_3", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["h1", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Image_35", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Line_1", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Line_1", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Content 1", "s-Content_1"]; 

	widgets.descriptionMap[["s-Paragraph_15", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Content 1", "s-Content_1"]; 

	widgets.descriptionMap[["s-Paragraph_14", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Content 1", "s-Content_1"]; 

	widgets.descriptionMap[["s-Paragraph_16", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Content 1", "s-Content_1"]; 

	widgets.descriptionMap[["s-Paragraph_18", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Content 1", "s-Content_1"]; 

	widgets.descriptionMap[["s-Image_13", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Dribbble circle icon", "s-Image_13"]; 

	widgets.descriptionMap[["s-Image_2", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["True", "s-Image_2"]; 

	widgets.descriptionMap[["s-Diamond", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Diamond", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Diamond", "s-Diamond"]; 

	widgets.descriptionMap[["s-Circle", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Circle", "s-Circle"]; 

	widgets.descriptionMap[["s-Paragraph", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Paragraph_1", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Rounded rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Paragraph_4", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["h2", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Input", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Paragraph_5", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Input_1", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_7", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Button", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Input_2", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Input_3", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Input_4", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "a2312798-627e-485b-9c6e-bd484c672cce"]] = ["Input Text Field", "s-Input_4"]; 

	