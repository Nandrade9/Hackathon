(function(window, undefined) {

  var jimLinks = {
    "c1fb4144-3169-4dd2-8b5f-a6413457e344" : {
      "Button" : [
        "a2312798-627e-485b-9c6e-bd484c672cce"
      ]
    },
    "0c624dc8-70cc-459f-96a6-ee401dcd0b18" : {
      "Button" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "bc778dde-907b-4bf8-8215-d2a82d89df7b" : {
      "Image_9" : [
        "a2312798-627e-485b-9c6e-bd484c672cce"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button" : [
        "a2312798-627e-485b-9c6e-bd484c672cce"
      ]
    },
    "a2312798-627e-485b-9c6e-bd484c672cce" : {
      "Image_2" : [
        "c1fb4144-3169-4dd2-8b5f-a6413457e344"
      ],
      "Diamond" : [
        "bc778dde-907b-4bf8-8215-d2a82d89df7b"
      ],
      "Circle" : [
        "0c624dc8-70cc-459f-96a6-ee401dcd0b18"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);