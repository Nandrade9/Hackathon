(function(window, undefined) {
  var dictionary = {
    "c1fb4144-3169-4dd2-8b5f-a6413457e344": "Asignatura",
    "0c624dc8-70cc-459f-96a6-ee401dcd0b18": "CONTROL",
    "bc778dde-907b-4bf8-8215-d2a82d89df7b": "Cooperación",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Screen 1",
    "a2312798-627e-485b-9c6e-bd484c672cce": "Docente",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);